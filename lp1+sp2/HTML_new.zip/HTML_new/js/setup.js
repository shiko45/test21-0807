    //画像保護
    $(function(){
        $('img').attr('onmousedown', 'return false');
        $('img').attr('onselectstart', 'return false');
        $('img').attr('oncontextmenu', 'return false');
    });

    //inview
    $(function() {
        $('.faderight1').css('opacity',0);
        $('.faderight1').on('inview', function(event, isInView) {if (isInView) {$(".faderight1").addClass('animated').addClass('fadeInRight');}});
        $('.faderight2').css('opacity',0);
        $('.faderight2').on('inview', function(event, isInView) {if (isInView) {$(".faderight2").addClass('animated').addClass('fadeInRight');}});
        $('.faderight3').css('opacity',0);
        $('.faderight3').on('inview', function(event, isInView) {if (isInView) {$(".faderight3").addClass('animated').addClass('fadeInRight');}});

        $('.fadedown1').css('opacity',0);
        $('.fadedown1').on('inview', function(event, isInView) {if (isInView) {$(".fadedown1").addClass('animated').addClass('fadeInDown');}});

        $('.fadeup1').css('opacity',0);
        $('.fadeup1').on('inview', function(event, isInView) {if (isInView) {$(".fadeup1").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup2').css('opacity',0);
        $('.fadeup2').on('inview', function(event, isInView) {if (isInView) {$(".fadeup2").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup3').css('opacity',0);
        $('.fadeup3').on('inview', function(event, isInView) {if (isInView) {$(".fadeup3").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup4').css('opacity',0);
        $('.fadeup4').on('inview', function(event, isInView) {if (isInView) {$(".fadeup4").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup5').css('opacity',0);
        $('.fadeup5').on('inview', function(event, isInView) {if (isInView) {$(".fadeup5").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup6').css('opacity',0);
        $('.fadeup6').on('inview', function(event, isInView) {if (isInView) {$(".fadeup6").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup7').css('opacity',0);
        $('.fadeup7').on('inview', function(event, isInView) {if (isInView) {$(".fadeup7").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup8').css('opacity',0);
        $('.fadeup8').on('inview', function(event, isInView) {if (isInView) {$(".fadeup8").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup9').css('opacity',0);
        $('.fadeup9').on('inview', function(event, isInView) {if (isInView) {$(".fadeup9").addClass('animated').addClass('fadeInUp');}});

        $('.fadeup10').css('opacity',0);
        $('.fadeup10').on('inview', function(event, isInView) {if (isInView) {$(".fadeup10").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup11').css('opacity',0);
        $('.fadeup11').on('inview', function(event, isInView) {if (isInView) {$(".fadeup11").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup12').css('opacity',0);
        $('.fadeup12').on('inview', function(event, isInView) {if (isInView) {$(".fadeup12").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup13').css('opacity',0);
        $('.fadeup13').on('inview', function(event, isInView) {if (isInView) {$(".fadeup13").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup14').css('opacity',0);
        $('.fadeup14').on('inview', function(event, isInView) {if (isInView) {$(".fadeup14").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup15').css('opacity',0);
        $('.fadeup15').on('inview', function(event, isInView) {if (isInView) {$(".fadeup15").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup16').css('opacity',0);
        $('.fadeup16').on('inview', function(event, isInView) {if (isInView) {$(".fadeup16").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup17').css('opacity',0);
        $('.fadeup17').on('inview', function(event, isInView) {if (isInView) {$(".fadeup17").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup18').css('opacity',0);
        $('.fadeup18').on('inview', function(event, isInView) {if (isInView) {$(".fadeup18").addClass('animated').addClass('fadeInUp');}});
        $('.fadeup19').css('opacity',0);
        $('.fadeup19').on('inview', function(event, isInView) {if (isInView) {$(".fadeup19").addClass('animated').addClass('fadeInUp');}});
    });